<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Perfil de Pokémon</title>
</head>
<body>
    <?php include 'head.php';?>

    <div class="container mt-5">
        <?php
        // Función para obtener datos de una URL dada
        function fetchData($url) {
            $response = @file_get_contents($url);
            if ($response === FALSE) {
                return null;
            }
            return json_decode($response, true);
        }

        // Obtener el ID del Pokémon de la URL de forma segura
        $pokemonId = null;
        if (isset($_GET['id']) && is_numeric($_GET['id'])) {
            $pokemonId = (int)$_GET['id']; 
        }

        // Si se obtuvo un ID válido, intenta cargar los detalles del Pokémon
        if ($pokemonId) {
            $pokemonApiUrl = "https://pokeapi.co/api/v2/pokemon/" . $pokemonId . "/";
            $pokemonDetails = fetchData($pokemonApiUrl);

            // Si se pudieron cargar los detalles del Pokémon
            if ($pokemonDetails) {
                $pokemonName = htmlspecialchars(ucfirst($pokemonDetails['name']));
                $pokemonImage = htmlspecialchars($pokemonDetails['sprites']['other']['home']['front_default']);
                $pokemonHeight = $pokemonDetails['height'] / 10; // API en decímetros, convertimos a metros
                $pokemonWeight = $pokemonDetails['weight'] / 10; // API en hectogramos, convertimos a kilogramos

                // Obtener tipos
                $types = [];
                foreach ($pokemonDetails['types'] as $typeInfo) {
                    $types[] = htmlspecialchars(ucfirst($typeInfo['type']['name']));
                }
                $pokemonTypes = implode(', ', $types); // Une los tipos con comas

                // Obtener habilidades (solo las no ocultas)
                $abilities = [];
                foreach ($pokemonDetails['abilities'] as $abilityInfo) {
                    if (!$abilityInfo['is_hidden']) {
                         $abilities[] = htmlspecialchars(ucfirst($abilityInfo['ability']['name']));
                    }
                }
                $pokemonAbilities = implode(', ', $abilities); // Une las habilidades con comas

                // Obtener estadísticas base (ej. HP, Attack, Defense)
                $stats = [];
                foreach ($pokemonDetails['stats'] as $statInfo) {
                    $statName = htmlspecialchars(ucfirst(str_replace('-', ' ', $statInfo['stat']['name']))); // Limpiar nombre de la estadística
                    $baseStat = $statInfo['base_stat'];
                    $stats[] = "<strong>{$statName}:</strong> {$baseStat}";
                }
                $pokemonStats = implode('<br>', $stats); // Une las estadísticas con saltos de línea

                ?>
                <div class="card mx-auto" style="max-width: 600px;">
                    <img class="card-img-top mx-auto d-block mt-3" src="<?php echo $pokemonImage; ?>" alt="Imagen de <?php echo $pokemonName; ?>" style="max-width: 250px;">
                    <div class="card-body text-center">
                        <h2 class="card-title"><?php echo $pokemonName; ?> (#<?php echo $pokemonId; ?>)</h2>
                        <hr>
                        <p class="card-text"><strong>Altura:</strong> <?php echo $pokemonHeight; ?> m</p>
                        <p class="card-text"><strong>Peso:</strong> <?php echo $pokemonWeight; ?> kg</p>
                        <p class="card-text"><strong>Tipo(s):</strong> <?php echo $pokemonTypes; ?></p>
                        <?php if (!empty($pokemonAbilities)): ?>
                            <p class="card-text"><strong>Habilidades:</strong> <?php echo $pokemonAbilities; ?></p>
                        <?php endif; ?>
                        <h5 class="mt-4">Estadísticas Base:</h5>
                        <p class="card-text"><?php echo $pokemonStats; ?></p>
                        <a href="index.php" class="btn btn-primary mt-3">Volver a la lista</a>
                    </div>
                </div>
                <?php
            } else {
                // Mensaje si no se pudieron cargar los detalles del Pokémon
                echo '<div class="alert alert-warning text-center" role="alert">No se pudieron cargar los detalles de este Pokémon. Asegúrate de que el ID sea correcto y tengas conexión a internet.</div>';
            }
        } else {
            // Mensaje si el ID no es válido o no se especifica
            echo '<div class="alert alert-danger text-center" role="alert">ID de Pokémon no especificado o inválido. Por favor, regresa a la lista y selecciona un Pokémon válido.</div>';
        }
        ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <?php include 'footer.php'; ?>
</body>
</html>
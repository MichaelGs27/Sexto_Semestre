<footer class="bg-dark text-white mt-5">
    <div class="container text-center">
        <hr class="my-2 border-light">
        <p class="mb-0">&copy; <?php echo date("Y"); ?> Pokémon App. Todos los derechos reservados.</p>
    </div>
</footer>
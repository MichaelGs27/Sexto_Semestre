<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>PokeAPI con PHP</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
  <?php include 'head.php'; // Aquí se incluye la barra de navegación ?>

  <div class="container mt-4">
    <div class="row" id="resultados">
      <?php
      // Función para consumir la API
      function fetchData($url) {
          $response = @file_get_contents($url);
          if ($response === FALSE) {
              return null;
          }
          return json_decode($response, true);
      }

      $pokemonListUrl = "https://pokeapi.co/api/v2/pokemon?limit=50&offset=0";
      $pokemonListData = fetchData($pokemonListUrl);

      if ($pokemonListData && isset($pokemonListData['results'])) {
          foreach ($pokemonListData['results'] as $pokemon) {
              $pokemonDetails = fetchData($pokemon['url']);

              if ($pokemonDetails) {
                  $pokemonId = $pokemonDetails['id'];
                  $pokemonName = htmlspecialchars(ucfirst($pokemonDetails['name']));
                  $pokemonImage = $pokemonDetails['sprites']['other']['home']['front_default'];

                  echo '<div class="col-md-4 mb-4">';
                  echo '<div class="card h-100">';
                  echo '<img class="card-img-top mx-auto mt-3" src="' . htmlspecialchars($pokemonImage) . '" alt="Imagen de ' . $pokemonName . '" style="max-width: 150px;">';
                  echo '<div class="card-body text-center">';
                  echo '<h4 class="card-title">' . $pokemonName . '</h4>';
                  echo '<a href="caracteristicas.php?id=' . $pokemonId . '" class="btn btn-primary mt-2">Ver Pokémon</a>';
                  echo '</div>';
                  echo '</div>';
                  echo '</div>';
              }
          }
      } else {
          echo '<p class="text-center col-12">Error: No se pudieron obtener los datos de Pokémon.</p>';
      }
      ?>
    </div>
  </div>

  <script src="script.js"></script>
  <?php include 'footer.php'; // Aquí se incluye el pie de página ?>
</body>
</html>
